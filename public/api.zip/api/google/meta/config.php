<?php
// header('Access-Control-Allow-Origin: *');

// Domain
define("domain", 'https://suite.social/manage.php');
